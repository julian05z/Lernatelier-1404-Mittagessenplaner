module.exports = {
    InitialData: [
        
        {
            login: 1,
            name: "Samuel Brunner",
            passwort: 12345
        },

        {
            login: 2,
            name: "Tiago Friedli",
            passwort: 098765
        },

        {
            login: 3,
            name: "Nikola Curaz",
            passwort: 19283
        },

        {
            login: 4,
            name: "Thierry Gambon",
            passwort: 123678
        },

        {
            login: 5, 
            name: "Loris Konetzny",
            passwort: 192837
        },

        {
            login: 6,
            name: "Jeremy Bärlocher",
            passwort: 543210
        },

        {
            login: 7,
            name: "Lukas Bargiesen",
            passwort: 9876543
        }


    ]
    }   ;