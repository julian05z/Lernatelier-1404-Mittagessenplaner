const mongoose = require("mongoose");
const express = require("express");
const cors = require("cors");

const url =
  "mongodb+srv://julianzurkinden:julianzurkinden@la1304.iss6ctc.mongodb.net/?retryWrites=true&w=majority";

const app = express();
app.use(cors());

const newSchema = new mongoose.Schema({
  name: String,
  email: String,
  benutzername: String,
  passwort: Number,
});

const newModel = mongoose.model("data", newSchema);

mongoose.connect(url).then(() => {
  console.log("Connected!");
});

app.get("/datas", (req, res) => {
  newModel
    .find({}, { _id: 0 }, (err, data) => {
      res.json(data);
    })
    .catch((err) => console.log(err));
});

app.listen(5500, () => {
  console.log("Server is running on port 3000");
});
