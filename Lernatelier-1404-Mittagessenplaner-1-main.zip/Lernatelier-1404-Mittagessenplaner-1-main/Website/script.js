fetch('http://localhost:5500/Login.datas/')
 .then((response) => response.json())
 .then(data => {
    console.log(data)
 })
